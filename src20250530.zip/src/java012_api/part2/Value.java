package java012_api.part2;

public class Value /* extends Object*/{
	int a;
	
	public Value() {
		
	}
	
	public Value(int a) {
		this.a = a;
	}

}
