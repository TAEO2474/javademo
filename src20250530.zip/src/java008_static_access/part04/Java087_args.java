package java008_static_access.part04;
// run -> run configuration -> Arguments ->Hello world 2025 입력
public class Java087_args {

	public static void main(String[] args) {
		for (String data : args) {
		System.out.println(data);
		}

	}

}
