package java010_abstract_interface.part06;

public interface Print {
	String toPaint(); //public abstract (생략)
}
