package java010_abstract_interface.part07;


public class UserTest extends FinalTest {

	public UserTest() {
		
	}
	
	@Override
	void display() {
		System.out.println("UserFinal Test display()");
	}
	
	
	
	
	

}
