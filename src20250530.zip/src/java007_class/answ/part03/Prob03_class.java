package java007_class.answ.part03;

/*
 * [출력결과]
 * 이름         	 투구이닝     	자책점     	  방어율
 * 박찬호       	  101        56       4.99
 * 노모히데오   	  100        46       4.14
 * 베이브루스   	  110        70      14.14
 * 김광현        	  109        68       5.61
 * 류현진        	  129        55       3.83
 */

public class Prob03_class {

	public static void main(String[] args) {
		Pitcher[] arr=new Pitcher[5];
		//문제를 풀때 아래 주석을 해제합니다.
		 arr[0]=new Pitcher("박찬호",101,56,4.99);
		 arr[1]=new Pitcher("노모히데오",100,46,4.14);
		 arr[2]=new Pitcher("베이브루스",110,70,14.14);
		 arr[3]=new Pitcher("김광현",109,68,5.61);
		 arr[4]=new Pitcher("류현진",129,55,3.83);
		 	display(arr);	 
	}//end main()
	
	public static void display(Pitcher[] arr){
		//이름과 투구이닝 자책점 방어율 순으로 출력하는 로직 구현
		System.out.println("이름      투구이닝      자책점      방어율");
		for(int i=0;i<arr.length;i++){
		System.out.println(arr[i].toString());
		}		
	}//end display( )

}//end class