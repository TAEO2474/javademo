package java006_class.prob.part02;



/* [실행결과]를 참조하여  main() 메소드에 로직을 추가하세요.
 * 
 * [실행결과]
 * 생성자 호출됨
 * Bible 작자미상
 */

public class Prob02_class {

	public static void main(String[] args) {
		Book javaBook = new Book("Java", "황기태");
		Book bible = new Book("Bible");
		Book emptyBook = new Book();
		/////////여기에 구현하세요.
		
		/////////////////////////////////////

	}//end main( )

}//end class
