package java009_inheritance.part02;

public class MyChild extends MyFather {
	public MyChild() {//2
		super ();//3
		System.out.println("MyChild");//12
	}//13

}// end class
