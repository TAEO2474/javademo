package java009_inheritance.part02;

public class MyFather extends MyGrand{
	public MyFather() {//4
		super ();//상속을 받은 부몬 클래스로 이동 //5
		System.out.println("MyFather");//10
	}//11

}
