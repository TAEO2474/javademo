package java009_inheritance.part03;

public class SubConst extends  SuperConst {
	// 생성자
	public SubConst(int x, int y) {//2
		super(x,y); // 부모클라스 x = 10, y = 20 //3
	}//9

}// end class
