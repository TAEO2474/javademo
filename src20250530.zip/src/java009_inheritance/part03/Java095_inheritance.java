package java009_inheritance.part03;

import java.util.Scanner;

public class Java095_inheritance {

	public static void main(String[] args) {
		SubConst sc = new SubConst(10, 20); //1
		System.out.printf("x=%d, y=%d\n", sc.x, sc.y);//10
	}//end main 11

}// end class 12
