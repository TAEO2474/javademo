package java009_inheritance.part01;
// 상속관계   ( is a 관계)
public class Child extends Father{ //(Child <-  Father)
	public Child() {
	}
	
	public void process() {
		System.out.println(a);
	}
}
