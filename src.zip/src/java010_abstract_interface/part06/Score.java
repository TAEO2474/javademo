package java010_abstract_interface.part06;

public interface Score {
    int sol = 20; //public static final (생략)
    
    int getScore(); //public abstract (생략)

}
