package java010_abstract_interface.part05;

public interface SampleA {
	void prn();

}
