package java010_abstract_interface.prob.part03;

//포유류
public interface Mammal {
	abstract void bear(); // 새끼를 낳음
}
