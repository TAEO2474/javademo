package java010_abstract_interface.part07;

//public class Expand extends Base {}




