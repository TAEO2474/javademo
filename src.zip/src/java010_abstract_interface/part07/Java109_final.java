package java010_abstract_interface.part07;

public class Java109_final {
	final int DATA = 10 ;//관례상 클래스에서 상수 입력시 대문자로, 가독성 높이기 위해서)
	// 상수에는 새로운 값을 아래와같이 할당할 수 없다.
	// DATA = 20;

	public static void main(String[] args) {
		
	} //end mian

	
}//end class
