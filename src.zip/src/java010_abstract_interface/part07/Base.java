package java010_abstract_interface.part07;

//public final class Base {
final public class Base {

	public Base() {
		

}
}
