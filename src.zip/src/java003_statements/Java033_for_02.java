package java003_statements;

public class Java033_for_02 {

	public static void main(String[] args) {
		for (int row =1; row <=4; row++) { 
			// data = 1 
			for (int col =1; col <=5; col++) {
				System.out.printf("%4d",col);
			}
			System.out.println("\n");
		}
	}

}
