package java015_exception;
//Java166_exception과 함께 보기
//사용자 정의 예외
public class UserException extends Exception {

	public UserException(String message) {
	 super (message);

	}

}
