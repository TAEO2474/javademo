package java009_inheritance.part02;

public class MyGrand {
	public MyGrand() {//6
		 super ();//7
		System.out.println("MyGrand");//8
	}//9
}
