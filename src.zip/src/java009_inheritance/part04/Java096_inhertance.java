package java009_inheritance.part04;

public class Java096_inhertance {

	public static void main(String[] args) {
		Sun sun = new Sun("TaeO", 30, "기획부",50000);
		System.out.println(sun.toString());
	
		Sun sun1 = new Sun("Jhon", 46, "인사팀",70000);
		System.out.println(sun1.toString());

	}

}
