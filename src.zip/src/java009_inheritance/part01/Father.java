package java009_inheritance.part01;

public class Father {
	int a = 3;
	private int c =10;
		
	public Father() {
	}
	public void display( ) {
	 System.out.println("a=" + a);
	 System.out.println("c=" + c);
	}

}
