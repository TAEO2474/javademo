package java009_inheritance.part07;
//다음과 같은 결과가 나오도록 구현하시오.
//(단, main()안의 내용수정과 새로운 Method추가하지마시오)
//
//*** x,y,z에 값채우기***
//10을 넘겨받은 생성자
//10   20   을 넘겨받은 생성자
//10   20   30  을 넘겨받은 생성자
//10   20   30
//합 : 60


public class Java099_inheritance {

	public static void main(String[] args) {
		SubClass ss = new SubClass(10, 20, 30);//1
		
		

	}// end main //30

}
