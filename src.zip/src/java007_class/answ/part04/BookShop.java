package java007_class.answ.part04;


/*

클래스명 : BookShop
+title:str
+code:str
+price:int

*/
public class BookShop {
	//멤버변수
	String title;
	String code;
	int price;

	BookShop(String title, String code, int price) {
		this.title = title;
		this.code = code;
		this.price = price;
	}
}//end class
